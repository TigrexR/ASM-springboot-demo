package com.tigrex.bytecode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BytecodeApplicationTests {

	@Test
	public void contextLoads() {

		System.out.println("hello world!");

	}

}
