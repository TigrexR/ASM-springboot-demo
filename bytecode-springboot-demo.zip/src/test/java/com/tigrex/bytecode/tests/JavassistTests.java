package com.tigrex.bytecode.tests;

import org.junit.Test;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.NotFoundException;

/**
 * @author linus
 */
public class JavassistTests {

    @Test
    public void tests() throws NotFoundException {
        ClassPool pool = new ClassPool();
        pool.appendSystemPath();
        CtClass ctClass = pool.get("com.tigrex.bytecode.tests.Demo");
        CtMethod method = ctClass.getDeclaredMethods()[0];
    }
}
