package com.tigrex.bytecode.tests;

public class Demo {
    public void hello () {
        System.out.println("hello world");
    }

    public String bar() { return null; }
    public String foo() { return null; }
    public String foo(Object o) { return null; }
}
