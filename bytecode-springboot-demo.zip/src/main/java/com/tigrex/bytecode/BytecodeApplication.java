package com.tigrex.bytecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author linus
 */
@SpringBootApplication
public class BytecodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BytecodeApplication.class, args);
	}
}
