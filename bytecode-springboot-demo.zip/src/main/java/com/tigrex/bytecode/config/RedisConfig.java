package com.tigrex.bytecode.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author linus
 */
@Configuration
public class RedisConfig {

}
